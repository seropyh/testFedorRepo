ResultScript()
{
	lr_start_transaction("start_login");

	web_url("confluence.ca.sbrf.ru",
		"URL=https://confluence.ca.sbrf.ru/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://confluence.ca.sbrf.ru/login.action?logout=true", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	web_url("login.action",
		"URL=https://confluence.ca.sbrf.ru/login.action?os_destination=%2F",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://confluence.ca.sbrf.ru/",
		"Snapshot=t3.inf",
		"Mode=HTML",
				LAST);
	web_submit_data("dologin.action",
                "Action=https://confluence.ca.sbrf.ru/dologin.action",
                "Method=POST",
                "RecContentType=text/html",
                "Referer=https://confluence.ca.sbrf.ru/login.action?logout=true",
                "Snapshot=t1.inf",
                "Mode=HTML",
                ITEMDATA,
                "Name=os_username","Value={os_username}",ENDITEM,
                "Name=os_password","Value={password}", ENDITEM,
                "Name=os_cookie","Value=true",ENDITEM,
                "Name=login", "Value=�����",ENDITEM,
                "Name=os_destination","Value=",ENDITEM, 
                LAST);
                
	lr_end_transaction("start_login", LR_AUTO);

	lr_start_transaction("questions");

//��������� �� �������
	web_url("questions", 
		"URL=https://confluence.ca.sbrf.ru/questions?src=header", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://confluence.ca.sbrf.ru/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);
		lr_end_transaction("questions", LR_AUTO);
	web_url("questions_2", 
		"URL=https://confluence.ca.sbrf.ru/rest/questions/1.0/questions/?startIndex=0&pageSize=20&filter=popular&_=1637670483072", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://confluence.ca.sbrf.ru/questions?src=header", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);	
		lr_end_transaction("questions", LR_AUTO);
		
		lr_start_transaction("themes");
		
//��������� �� ����
	web_url("topics", 
		"URL=https://confluence.ca.sbrf.ru/questions/topics", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://confluence.ca.sbrf.ru/questions?src=header", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);
		
	web_url("topic", 
		"URL=https://confluence.ca.sbrf.ru/rest/questions/1.0/topic/?startIndex=0&pageSize=15&isFeatured=true&loadAvatar=true&_=1637670487217", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://confluence.ca.sbrf.ru/questions/topics", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

lr_end_transaction("themes", LR_AUTO);
		
		
		lr_start_transaction("confa themes");
//��������� �� ���� �� �����
	web_url("confluence",
		"URL=https://confluence.ca.sbrf.ru/questions/topics/33161225/confluence",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://confluence.ca.sbrf.ru/questions/topics",
		"Snapshot=t19.inf",
		"Mode=HTML",
		LAST);
	lr_end_transaction("confa themes", LR_AUTO);

		lr_start_transaction("one theme");
// ���� ���������������
	web_url("My theme",
		"URL=https://confluence.ca.sbrf.ru/{Link_to_topic}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://confluence.ca.sbrf.ru/questions/topics/33161225/confluence",
		"Snapshot=t27.inf",
		"Mode=HTML",
		LAST);
	lr_end_transaction("one theme", LR_AUTO);
	lr_start_transaction("start_logout");;	
// ��������� �� ������� �������� �����
	web_url("confluence.ca.sbrf.ru", 
		"URL=https://confluence.ca.sbrf.ru/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://confluence.ca.sbrf.ru/login.action?logout=true", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		LAST);	
// ������� �� �����		
	web_url("logout.action",
		"URL=https://confluence.ca.sbrf.ru/logout.action",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://confluence.ca.sbrf.ru/questions/topics/33161225/confluence",
		"Snapshot=t116.inf",
		"Mode=HTML",
		LAST);
	lr_end_transaction("start_logout", LR_AUTO);

		return 0;
}
